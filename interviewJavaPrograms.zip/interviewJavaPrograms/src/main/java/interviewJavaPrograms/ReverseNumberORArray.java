package interviewJavaPrograms;

public class ReverseNumberORArray {

	public static void main(String[] args) {
		int[] n = {1,2,25,6,7,8};
		for(int i=n.length-1; i>=0;i--) {
			System.out.print(n[i] +" ");
		}
	}

}
